package com.example.salary_slip

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
